import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-place-appointment',
  templateUrl: './place-appointment.component.html',
  styleUrls: ['./place-appointment.component.scss']
})
export class PlaceAppointmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  action(){
    alert("Submitted Successfully");
    console.log("Appointment booked");
  }

}
